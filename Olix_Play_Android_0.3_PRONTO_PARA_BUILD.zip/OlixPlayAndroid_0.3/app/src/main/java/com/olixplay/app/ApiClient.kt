package com.olixplay.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class OlixConfig(val server: String, val username: String, val password: String)
data class Category(val id: String, val name: String)
data class MediaItem(val id: String, val name: String, val streamUrl: String, val logo: String? = null, val categoryId: String? = null, val type: String)
data class SeriesInfo(val id: String, val name: String, val plot: String, val cover: String?, val categoryId: String?)
data class Episode(val id: String, val season: Int, val episode: Int, val title: String, val url: String, val extension: String)

class ApiClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private fun base(config: OlixConfig) = config.server.trimEnd('/')

    private suspend fun request(config: OlixConfig, action: String? = null, categoryId: String? = null, seriesId: String? = null): String = withContext(Dispatchers.IO) {
        val builder = "${base(config)}/player_api.php".toHttpUrl().newBuilder()
            .addQueryParameter("username", config.username)
            .addQueryParameter("password", config.password)
        if (!action.isNullOrBlank()) builder.addQueryParameter("action", action)
        if (!categoryId.isNullOrBlank()) builder.addQueryParameter("category_id", categoryId)
        if (!seriesId.isNullOrBlank()) builder.addQueryParameter("series_id", seriesId)
        val response = http.newCall(Request.Builder().url(builder.build()).get().build()).execute()
        if (!response.isSuccessful) error("Servidor retornou HTTP ${response.code}")
        response.body?.string() ?: error("Resposta vazia do servidor")
    }

    suspend fun authenticate(config: OlixConfig): Boolean {
        val info = JSONObject(request(config)).optJSONObject("user_info") ?: return false
        return info.optString("auth") == "1"
    }

    suspend fun liveCategories(config: OlixConfig) = parseCategories(request(config, "get_live_categories"))
    suspend fun vodCategories(config: OlixConfig) = parseCategories(request(config, "get_vod_categories"))
    suspend fun seriesCategories(config: OlixConfig) = parseCategories(request(config, "get_series_categories"))

    suspend fun live(config: OlixConfig, categoryId: String? = null) = parseMedia(JSONArray(request(config, "get_live_streams", categoryId)), config, "live")
    suspend fun vod(config: OlixConfig, categoryId: String? = null) = parseMedia(JSONArray(request(config, "get_vod_streams", categoryId)), config, "movie")
    suspend fun series(config: OlixConfig, categoryId: String? = null): List<SeriesInfo> {
        val arr = JSONArray(request(config, "get_series", categoryId))
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(SeriesInfo(o.optString("series_id"), o.optString("name"), o.optString("plot"), o.optString("cover").ifBlank { null }, o.optString("category_id").ifBlank { null }))
            }
        }
    }

    suspend fun seriesInfo(config: OlixConfig, seriesId: String): Pair<SeriesInfo, List<Episode>> {
        val root = JSONObject(request(config, "get_series_info", null, seriesId))
        return parseSeriesInfo(root, config, seriesId)
    }

    private fun parseSeriesInfo(root: JSONObject, config: OlixConfig, id: String): Pair<SeriesInfo, List<Episode>> {
        val info = root.optJSONObject("info") ?: JSONObject()
        val series = SeriesInfo(id, info.optString("name"), info.optString("plot"), info.optString("cover").ifBlank { null }, null)
        val episodes = mutableListOf<Episode>()
        val seasons = root.optJSONObject("episodes") ?: JSONObject()
        val seasonKeys = seasons.keys()
        while (seasonKeys.hasNext()) {
            val seasonKey = seasonKeys.next()
            val seasonNo = seasonKey.toIntOrNull() ?: 0
            val arr = seasons.optJSONArray(seasonKey) ?: continue
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val epId = e.optString("id").ifBlank { e.optString("episode_id") }
                val ext = e.optString("container_extension").ifBlank { "mp4" }
                val url = "${base(config)}/series/${config.username}/${config.password}/$epId.$ext"
                episodes += Episode(epId, seasonNo, e.optInt("episode_num"), e.optString("title").ifBlank { "Episódio ${e.optInt("episode_num")}" }, url, ext)
            }
        }
        return series to episodes
    }

    private fun parseCategories(raw: String): List<Category> {
        val arr = JSONArray(raw)
        return buildList { for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); add(Category(o.optString("category_id"), o.optString("category_name"))) } }
    }

    private fun parseMedia(arr: JSONArray, config: OlixConfig, type: String): List<MediaItem> {
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("stream_id")
                val ext = o.optString("container_extension").ifBlank { if (type == "live") "ts" else "mp4" }
                val path = if (type == "live") "live" else "movie"
                add(MediaItem(id, o.optString("name"), "${base(config)}/$path/${config.username}/${config.password}/$id.$ext", o.optString("stream_icon").ifBlank { null }, o.optString("category_id").ifBlank { null }, type))
            }
        }
    }
}
