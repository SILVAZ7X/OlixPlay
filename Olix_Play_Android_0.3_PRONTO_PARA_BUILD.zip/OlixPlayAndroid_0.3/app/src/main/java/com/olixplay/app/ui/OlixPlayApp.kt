package com.olixplay.app.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.olixplay.app.*
import kotlinx.coroutines.launch

private val Background = Color(0xFF090A13)
private val Surface = Color(0xFF15182A)
private val Accent = Color(0xFF7C4DFF)

@Composable
fun OlixPlayApp() {
    MaterialTheme(colorScheme = darkColorScheme(background = Background, surface = Surface, primary = Accent)) {
        var config by remember { mutableStateOf<OlixConfig?>(null) }
        if (config == null) LoginScreen { config = it } else HomeScreen(config!!)
    }
}

@Composable
private fun LoginScreen(onConnected: (OlixConfig) -> Unit) {
    val scope = rememberCoroutineScope(); val api = remember { ApiClient() }
    var server by remember { mutableStateOf("") }; var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }; var error by remember { mutableStateOf<String?>(null) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF090A13), Color(0xFF19112E))))) {
        Column(Modifier.fillMaxWidth().padding(24.dp).align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Olix Play", fontSize = 42.sp, fontWeight = FontWeight.Black)
            Text("Seu conteúdo, do seu jeito", color = Color.LightGray)
            Spacer(Modifier.height(28.dp))
            OutlinedTextField(server, { server = it }, label = { Text("Servidor") }, placeholder = { Text("https://seu-servidor.com") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(user, { user = it }, label = { Text("Usuário") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(pass, { pass = it }, label = { Text("Senha") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            Button(enabled = !busy && server.isNotBlank() && user.isNotBlank() && pass.isNotBlank(), onClick = {
                busy = true; error = null; scope.launch {
                    try { val cfg = OlixConfig(server.trimEnd('/'), user, pass); if (api.authenticate(cfg)) onConnected(cfg) else error = "Usuário ou senha inválidos." }
                    catch (e: Exception) { error = e.message ?: "Não foi possível conectar ao servidor." } finally { busy = false }
                }
            }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(if (busy) "Conectando..." else "ENTRAR") }
            error?.let { Spacer(Modifier.height(12.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun HomeScreen(config: OlixConfig) {
    val api = remember { ApiClient() }; val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }; var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var liveItems by remember { mutableStateOf<List<MediaItem>>(emptyList()) }; var vodItems by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var seriesItems by remember { mutableStateOf<List<SeriesInfo>>(emptyList()) }; var loading by remember { mutableStateOf(true) }; var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<MediaItem?>(null) }

    fun load(categoryId: String? = null) {
        loading = true; error = null; scope.launch {
            try { when (tab) {
                0 -> { categories = api.liveCategories(config); liveItems = api.live(config, categoryId) }
                1 -> { categories = api.vodCategories(config); vodItems = api.vod(config, categoryId) }
                2 -> { categories = api.seriesCategories(config); seriesItems = api.series(config, categoryId) }
            }} catch (e: Exception) { error = e.message ?: "Erro ao carregar conteúdo." } finally { loading = false }
        }
    }
    LaunchedEffect(tab) { load() }

    if (playing != null) { PlayerScreen(playing!!) { playing = null }; return }

    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text("Olix Play", fontWeight = FontWeight.Bold) }) }, bottomBar = {
        NavigationBar {
            NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.LiveTv, null) }, label = { Text("Ao vivo") })
            NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Movie, null) }, label = { Text("Filmes") })
            NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Tv, null) }, label = { Text("Séries") })
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
            if (categories.isNotEmpty()) {
                Text("Categorias", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
                Row(Modifier.fillMaxWidth().height(46.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = { load() }, label = { Text("Todas") })
                    categories.take(3).forEach { c -> AssistChip(onClick = { load(c.id) }, label = { Text(c.name, maxLines = 1) }) }
                }
            }
            if (loading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else if (error != null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(error!!, color = MaterialTheme.colorScheme.error) }
            else if (tab == 2) {
                LazyColumn(Modifier.fillMaxSize()) { items(seriesItems) { s -> MediaCard(s.name, s.cover) { scope.launch { try { val (_, eps) = api.seriesInfo(config, s.id); if (eps.isNotEmpty()) playing = MediaItem(eps.first().id, eps.first().title, eps.first().url, s.cover, null, "series") } catch (_: Exception) {} } } } }
            } else {
                val list = if (tab == 0) liveItems else vodItems
                LazyColumn(Modifier.fillMaxSize()) { items(list) { item -> MediaCard(item.name, item.logo) { playing = item } } }
            }
        }
    }
}

@Composable
private fun MediaCard(name: String, image: String?, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable(onClick = onClick), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PlayCircle, null, tint = Accent, modifier = Modifier.size(36.dp)); Spacer(Modifier.width(12.dp)); Text(name, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun PlayerScreen(item: MediaItem, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember(item.streamUrl) { ExoPlayer.Builder(context).build().apply { setMediaItem(ExoMediaItem.fromUri(Uri.parse(item.streamUrl))); prepare(); playWhenReady = true } }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }; Text(item.name, color = Color.White, fontWeight = FontWeight.Bold) }
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f))
        Text("Olix Play", color = Color.LightGray, modifier = Modifier.padding(16.dp))
    }
}
